import os

# Dube Man Innovation - Supabase Client configuration for PC Agent
# Ensure to replace these values with your actual Supabase credentials or configure them in your environment.
SUPABASE_URL = os.getenv("SUPABASE_URL", "https://qrleqcssjscfgwdkkscm.supabase.co")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY", "sb_publishable_hxFD9g97PINyx-xVBiXKDw_t7Y1CidO")

# Time interval between heartbeat pings in seconds
HEARTBEAT_INTERVAL = 30
