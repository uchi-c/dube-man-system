#!/usr/bin/env python3
import os
import sys
import time
import socket
import requests
from datetime import datetime
import config

def get_computer_code():
    """Reads computer hostname as the computer code, with overrides from environment."""
    code = os.getenv("COMPUTER_CODE")
    if not code:
        # Get machine hostname (e.g. PC-01, DESKTOP-ABCDE)
        code = socket.gethostname().upper()
    return code

def get_computer_name(computer_code):
    """Generates a friendly display name based on computer code."""
    return f"Station {computer_code}"

def send_heartbeat():
    """Sends a machine heartbeat directly to the Supabase computers table."""
    code = get_computer_code()
    name = get_computer_name(code)
    
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Preparing heartbeat for {code}...")
    
    # Check if Supabase URL is default/placeholder
    if "your-supabase" in config.SUPABASE_URL or not config.SUPABASE_ANON_KEY or config.SUPABASE_ANON_KEY == "your-anon-key":
        print("⚠️ Warning: Supabase credentials are not configured in pc-agent/config.py or environment variables.")
        print("Please configure SUPABASE_URL and SUPABASE_ANON_KEY.")
        return False

    # Standard Supabase REST API headers
    headers = {
        "apikey": config.SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {config.SUPABASE_ANON_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=representation"
    }

    # ISO timestamp format (with 'Z' to represent UTC)
    now_iso = datetime.utcnow().isoformat() + "Z"

    # Step 1: Check if the computer already exists in the table
    query_url = f"{config.SUPABASE_URL}/rest/v1/computers?computer_code=eq.{code}"
    try:
        response = requests.get(query_url, headers=headers, timeout=10)
        if response.status_code == 200:
            computers = response.json()
            if computers:
                # Update existing computer record
                comp_id = computers[0]["id"]
                update_url = f"{config.SUPABASE_URL}/rest/v1/computers?id=eq.{comp_id}"
                
                # Keep active/occupied status if it's currently occupied
                current_status = computers[0].get("status", "Available")
                new_status = current_status if current_status == "Occupied" else "Available"
                
                payload = {
                    "last_seen": now_iso,
                    "status": new_status
                }
                
                upd_resp = requests.patch(update_url, headers=headers, json=payload, timeout=10)
                if upd_resp.status_code in [200, 201, 204]:
                    print(f"✅ Heartbeat success: Updated {code} (Status: {new_status}, Last Seen: {now_iso})")
                    return True
                else:
                    print(f"❌ Failed to update computer state. HTTP {upd_resp.status_code}: {upd_resp.text}")
            else:
                # Insert a new computer record for this workstation
                insert_url = f"{config.SUPABASE_URL}/rest/v1/computers"
                payload = {
                    "computer_code": code,
                    "computer_name": name,
                    "status": "Available",
                    "hourly_rate": 60.0,
                    "rate_per_minute": 1.0,
                    "last_seen": now_iso
                }
                
                ins_resp = requests.post(insert_url, headers=headers, json=payload, timeout=10)
                if ins_resp.status_code in [200, 201, 204]:
                    print(f"🎉 Registered new computer workstation: {code}")
                    return True
                else:
                    print(f"❌ Failed to register new computer. HTTP {ins_resp.status_code}: {ins_resp.text}")
        else:
            print(f"❌ Error contacting Supabase REST gateway. HTTP {response.status_code}: {response.text}")
    except Exception as e:
        print(f"🚨 Connection error to Supabase REST Gateway: {e}")
    
    return False

if __name__ == "__main__":
    code = get_computer_code()
    print("=" * 60)
    print("         DUBE MAN INNOVATION - INTERNET CAFE PC AGENT")
    print("=" * 60)
    print(f"Local machine hostname: {socket.gethostname()}")
    print(f"Target Workstation Code: {code}")
    print(f"Heartbeat Interval: {config.HEARTBEAT_INTERVAL} seconds")
    print(f"REST API Gateway: {config.SUPABASE_URL}")
    print("-" * 60)
    print("Agent started successfully. Sending first heartbeat signal...")
    
    while True:
        send_heartbeat()
        time.sleep(config.HEARTBEAT_INTERVAL)
