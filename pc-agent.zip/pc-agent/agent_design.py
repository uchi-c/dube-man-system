#!/usr/bin/env python3
"""
Dube Man Innovation - Internet Cafe Computer Agent
Platform Reference: Win32 / Linux Desktop Blocker & Heartbeat Daemon
Author: Senior Full-Stack Architect & Cybersecurity Engineer
"""

import os
import sys
import time
import json
import hmac
import hashlib
import requests

# Local agent configurations
COMPUTER_CODE = "PC-01"
API_URL = "https://your-supabase-project-id.supabase.co"
HMAC_SECRET = b"your_pc_agent_secure_hmac_secret_key" # Shared secret stored securely on host

def get_header_signature(payload_bytes: bytes) -> str:
    """Computes SHA256 HMAC for secure authenticated API heartbeats."""
    hashed = hmac.new(HMAC_SECRET, payload_bytes, hashlib.sha256)
    return hashed.hexdigest()

def send_heartbeat():
    """Sends a machine heartbeat to report back online, including local active memory load."""
    payload = {
        "computer_code": COMPUTER_CODE,
        "timestamp": int(time.time()),
        "status": "Available" # Or "Occupied" if lockscreen is disabled
    }
    
    data_str = json.dumps(payload).encode('utf-8')
    sig = get_header_signature(data_str)
    
    headers = {
        "Content-Type": "application/json",
        "X-Agent-Signature": sig
    }
    
    try:
        # Calls the edge functions endpoint or custom Express backend API proxy
        response = requests.post(f"{API_URL}/functions/v1/pc-heartbeat", data=data_str, headers=headers, timeout=5)
        if response.status_code == 200:
            print(f"[{COMPUTER_CODE}] Heartbeat validated with signature success.")
        else:
            print(f"[{COMPUTER_CODE}] Heartbeat failed code: {response.status_code}")
    except Exception as e:
        print(f"[{COMPUTER_CODE}] Communication link down: {e}")

def lock_screen():
    """Simulates locking task managers, overlaying full-screen modal."""
    print(f"[{COMPUTER_CODE}] SECURE ACTION: Block keyboard inputs and display overlay lockscreen.")

def unlock_screen():
    """Simulates unlocking workspace for current customer."""
    print(f"[{COMPUTER_CODE}] SECURE ACTION: Unlock terminal. User session active.")

if __name__ == "__main__":
    print(f"Initializing Dube Man Innovation Local Client Agent for {COMPUTER_CODE}...")
    # Main event loop
    while True:
        send_heartbeat()
        time.sleep(30) # Tick every 30 seconds
