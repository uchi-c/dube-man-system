# PC-Agent Hub - Dube Man Innovation
## Integrated Desktop Terminal Lock & Heartbeat Communicator

This folder contains the architectural blueprint and reference daemon implementation for the future native client application destined for client computers (PC-01, PC-02 ...) in the Dube Man Internet Café.

### Features
1. **Authenticated Heartbeat**: Sends self-signed JWT heartbeats to the centralized Supabase backend every 30 seconds.
2. **Dynamic Shell Lock/Unlock**: Listens to Supabase Realtime channel notifications for the respective `computer_code`. If a session is initiated, it opens the environment. If ended or expired, it overlays an un-bypassable desktop blocker shell.
3. **Session Duration Enforcements**: Local backup timer shuts down current screen if server link drops or time-limit expires.

---

### Encryption & Auth Handshake

To prevent malicious remote unlocking of workstations or interception, communication works via HMAC-SHA256 signature verification.

```
       [Centralized Supabase API] 
                  |
         (Realtime Event or API)
                  |
                  v
       [Local PC Lock Daemon]  <--- Validates HMAC signatures with per-device/backend-held secrets
                  | 
                  v 
        [Lock/Unlock Screen]
```

Review `agent_design.py` for the python-based reference design of this agent.

